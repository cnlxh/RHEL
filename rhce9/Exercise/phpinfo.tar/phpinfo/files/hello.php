Hello PHP World from <?php echo gethostname(); ?>
<?php phpinfo(); ?>
